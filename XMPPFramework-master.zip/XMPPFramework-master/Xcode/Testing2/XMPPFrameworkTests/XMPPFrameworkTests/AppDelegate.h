//
//  AppDelegate.h
//  XMPPFrameworkTests
//
//  Created by Paul Melnikow on 4/18/15.
//  Copyright (c) 2015 Paul Melnikow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

