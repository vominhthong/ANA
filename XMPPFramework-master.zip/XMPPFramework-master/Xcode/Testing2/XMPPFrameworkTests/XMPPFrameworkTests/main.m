//
//  main.m
//  XMPPFrameworkTests
//
//  Created by Paul Melnikow on 4/18/15.
//  Copyright (c) 2015 Paul Melnikow. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
