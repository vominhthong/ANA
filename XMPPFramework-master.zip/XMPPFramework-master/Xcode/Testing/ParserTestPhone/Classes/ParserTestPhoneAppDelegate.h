#import <UIKit/UIKit.h>

@interface ParserTestPhoneAppDelegate : NSObject <UIApplicationDelegate>
{
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

