//
// Created by Jonathon Staff on 10/21/14.
// Copyright (c) 2014 nplexity, LLC. All rights reserved.
//

#import "XMPPFileTransfer.h"


@implementation XMPPFileTransfer

@end